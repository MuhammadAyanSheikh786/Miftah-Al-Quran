import { motion } from 'framer-motion';
import { 
  BookOpen, 
  Users, 
  Award, 
  Target, 
  Heart, 
  Globe, 
  Quote,
  Star,
  CheckCircle2,
  ArrowRight,
  Play,
  Sparkles,
  GraduationCap,
  BookMarked
} from 'lucide-react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { CallToAction } from '@/components/home/CallToAction';
import { Button } from '@/components/ui/button';

const values = [
  {
    icon: BookOpen,
    title: 'Authentic Teaching',
    description: 'We follow traditional teaching methodologies passed down through generations of Islamic scholars.',
    color: 'from-emerald-500 to-teal-500',
    bgColor: 'bg-emerald-50',
    iconColor: 'text-emerald-600',
  },
  {
    icon: Users,
    title: 'Student-Centered',
    description: 'Our approach focuses on individual learning needs with personalized attention and guidance.',
    color: 'from-blue-500 to-cyan-500',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    icon: Award,
    title: 'Excellence',
    description: 'We strive for the highest standards in Quranic education and spiritual development.',
    color: 'from-amber-500 to-yellow-500',
    bgColor: 'bg-amber-50',
    iconColor: 'text-amber-600',
  },
  {
    icon: Target,
    title: 'Clear Goals',
    description: 'Structured curriculum with clear milestones to track your progress effectively.',
    color: 'from-rose-500 to-pink-500',
    bgColor: 'bg-rose-50',
    iconColor: 'text-rose-600',
  },
  {
    icon: Heart,
    title: 'Compassion',
    description: 'Creating a nurturing environment where every student feels supported and encouraged.',
    color: 'from-purple-500 to-violet-500',
    bgColor: 'bg-purple-50',
    iconColor: 'text-purple-600',
  },
  {
    icon: Globe,
    title: 'Global Reach',
    description: 'Connecting students worldwide with qualified teachers for accessible Islamic education.',
    color: 'from-indigo-500 to-blue-500',
    bgColor: 'bg-indigo-50',
    iconColor: 'text-indigo-600',
  },
];

const team = [
  {
    name: 'Sheikh Ahmad Al-Farooq',
    role: 'Founder & Lead Instructor',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
    description: 'Over 20 years of experience in Quranic education with Ijazah from renowned scholars.',
    credentials: ['PhD in Islamic Studies', 'Al-Azhar Graduate', '20+ Years Experience'],
    social: { linkedin: '#', twitter: '#' }
  },
  {
    name: 'Ustadh Muhammad Yusuf',
    role: 'Senior Tajweed Instructor',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    description: 'Specialized in Tajweed with certification from Al-Azhar University.',
    credentials: ['Tajweed Specialist', 'Ijazah Certified', '15+ Years Experience'],
    social: { linkedin: '#', twitter: '#' }
  },
  {
    name: 'Sister Aisha Rahman',
    role: 'Female Students Coordinator',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400',
    description: 'Dedicated to providing quality Quran education for sisters worldwide.',
    credentials: ['Islamic Education Expert', 'Curriculum Developer', '10+ Years Experience'],
    social: { linkedin: '#', twitter: '#' }
  },
];

const stats = [
  { value: '5,000+', label: 'Students Enrolled', icon: Users },
  { value: '100+', label: 'Certified Teachers', icon: GraduationCap },
  { value: '50+', label: 'Countries Reached', icon: Globe },
  { value: '98%', label: 'Success Rate', icon: Award },
];

const milestones = [
  { year: '2015', title: 'Foundation', description: 'Miftah Al Quran was established with a vision to make Quranic education accessible globally.' },
  { year: '2017', title: 'First 1000 Students', description: 'Reached our first major milestone with students from over 20 countries.' },
  { year: '2019', title: 'Curriculum Expansion', description: 'Launched advanced Tajweed and Hifz programs with certified instructors.' },
  { year: '2021', title: 'Global Recognition', description: 'Received accreditation and partnerships with renowned Islamic institutions.' },
  { year: '2023', title: '5000+ Community', description: 'Growing strong with a global community of dedicated learners and scholars.' },
];

const floatingAnimation = {
  y: [-10, 10, -10],
  transition: {
    duration: 6,
    repeat: Infinity,
    ease: "easeInOut"
  }
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  }
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-28 md:pt-36 pb-24 md:pb-32 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-teal-800 to-cyan-900">
          <div className="absolute inset-0 bg-[url('/pattern-islamic.svg')] opacity-5" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        </div>

        {/* Floating Elements */}
        <motion.div 
          animate={floatingAnimation}
          className="absolute top-20 left-[10%] w-32 h-32 bg-gold/10 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ ...floatingAnimation, transition: { ...floatingAnimation.transition, delay: 1 } }}
          className="absolute top-40 right-[15%] w-40 h-40 bg-emerald-400/10 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ ...floatingAnimation, transition: { ...floatingAnimation.transition, delay: 2 } }}
          className="absolute bottom-20 left-[20%] w-24 h-24 bg-cyan-400/10 rounded-full blur-2xl"
        />

        {/* Decorative Geometric Elements */}
        <div className="absolute top-20 right-10 opacity-20 hidden lg:block">
          <svg width="150" height="150" viewBox="0 0 150 150" className="text-gold">
            <polygon points="75,0 150,75 75,150 0,75" fill="none" stroke="currentColor" strokeWidth="1"/>
            <polygon points="75,25 125,75 75,125 25,75" fill="none" stroke="currentColor" strokeWidth="1"/>
            <polygon points="75,50 100,75 75,100 50,75" fill="none" stroke="currentColor" strokeWidth="1"/>
          </svg>
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center max-w-4xl mx-auto"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-8"
            >
              <Sparkles className="w-4 h-4 text-gold" />
              <span className="text-sm font-medium text-white/90">Established 2015 • Trusted Worldwide</span>
            </motion.div>

            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Illuminating Hearts{' '}
              <br className="hidden sm:block" />
              Through{' '}
              <span className="relative inline-block">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-300">
                  Quranic Knowledge
                </span>
                <motion.span 
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  transition={{ delay: 1, duration: 0.8 }}
                  className="absolute -bottom-2 left-0 h-1 bg-gradient-to-r from-amber-400 to-yellow-500 rounded-full"
                />
              </span>
            </h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-lg sm:text-xl text-white/80 max-w-3xl mx-auto leading-relaxed mb-12"
            >
              Miftah Al Quran (Key to the Quran) was founded with a sacred mission to make 
              authentic Quranic education accessible to every seeker of knowledge, anywhere in the world.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button 
                size="lg"
                className="h-14 px-8 rounded-xl bg-white text-emerald-900 hover:bg-white/90 shadow-xl shadow-black/20 text-base font-semibold transition-all duration-300 hover:scale-105"
              >
                <GraduationCap className="w-5 h-5 mr-2" />
                Start Learning Today
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="h-14 px-8 rounded-xl bg-white text-emerald-900 hover:bg-white/90 shadow-xl shadow-black/20 text-base font-semibold transition-all duration-300 hover:scale-105"
              >
                <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                Watch Our Story
              </Button>
            </motion.div>
          </motion.div>

          {/* Stats Bar */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mt-16 md:mt-20"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 max-w-5xl mx-auto">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.9 + index * 0.1 }}
                  className="text-center p-5 md:p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/15 transition-all duration-300"
                >
                  <div className="inline-flex p-2.5 rounded-xl bg-gradient-to-br from-amber-400/20 to-yellow-500/20 mb-3">
                    <stat.icon className="w-5 h-5 text-gold" />
                  </div>
                  <p className="text-2xl md:text-3xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-xs md:text-sm text-white/60 uppercase tracking-wide">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom Wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
            <path 
              d="M0 120L48 110C96 100 192 80 288 70C384 60 480 60 576 65C672 70 768 80 864 85C960 90 1056 90 1152 85C1248 80 1344 70 1392 65L1440 60V120H1392C1344 120 1248 120 1152 120C1056 120 960 120 864 120C768 120 672 120 576 120C480 120 384 120 288 120C192 120 96 120 48 120H0V120Z" 
              fill="rgb(248 250 252)"
            />
          </svg>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20 md:py-28 bg-slate-50 relative overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Content */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-100 border border-emerald-200 mb-6">
                <BookMarked className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-medium text-emerald-700">Our Story</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
                A Journey of{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">
                  Faith & Education
                </span>
              </h2>

              <div className="space-y-5 text-slate-600 leading-relaxed">
                <p className="text-lg">
                  Miftah Al Quran was established in <strong className="text-slate-900">2015</strong> by a group of dedicated Islamic 
                  scholars who recognized the urgent need for quality, accessible Quranic education 
                  in the digital age.
                </p>
                <p>
                  Our founders, all holding <strong className="text-slate-900">Ijazah certifications</strong> from renowned Islamic 
                  institutions including Al-Azhar University, envisioned a platform where students from any corner of 
                  the world could learn the Quran with proper guidance and authentic methodology.
                </p>
                <p>
                  Today, we have grown into a vibrant global community of over <strong className="text-slate-900">5,000 students</strong>, 
                  <strong className="text-slate-900"> 100+ certified teachers</strong>, and a comprehensive curriculum that covers 
                  everything from basic recitation to advanced Tajweed, Hifz, and Quranic Arabic.
                </p>
              </div>

              {/* Key Points */}
              <div className="mt-8 grid sm:grid-cols-2 gap-4">
                {[
                  'Ijazah Certified Teachers',
                  'Personalized Learning Paths',
                  'Flexible Scheduling',
                  'Global Community'
                ].map((point, index) => (
                  <motion.div
                    key={point}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <span className="text-slate-700 font-medium">{point}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Image Grid */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    className="rounded-2xl overflow-hidden shadow-xl"
                  >
                    <img
                      src="https://images.unsplash.com/photo-1585036156171-384164a8c675?w=600"
                      alt="Students learning Quran"
                      className="w-full h-48 md:h-56 object-cover"
                    />
                  </motion.div>
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    className="rounded-2xl overflow-hidden shadow-xl"
                  >
                    <img
                      src="https://images.unsplash.com/photo-1609599006353-e629aaabfeae?w=600"
                      alt="Quran study"
                      className="w-full h-32 md:h-40 object-cover"
                    />
                  </motion.div>
                </div>
                <div className="space-y-4 pt-8">
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    className="rounded-2xl overflow-hidden shadow-xl"
                  >
                    <img
                      src="https://images.unsplash.com/photo-1588345921523-c2dcdb7f1dcd?w=600"
                      alt="Islamic education"
                      className="w-full h-32 md:h-40 object-cover"
                    />
                  </motion.div>
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    className="rounded-2xl overflow-hidden shadow-xl"
                  >
                    <img
                      src="https://images.unsplash.com/photo-1577896851231-70ef18881754?w=600"
                      alt="Online learning"
                      className="w-full h-48 md:h-56 object-cover"
                    />
                  </motion.div>
                </div>
              </div>

              {/* Floating Stats Card */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="absolute -bottom-6 -left-6 md:-left-10"
              >
                <div className="bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-900 p-6 rounded-2xl shadow-2xl shadow-amber-200/50">
                  <p className="font-serif text-4xl md:text-5xl font-bold">8+</p>
                  <p className="text-sm font-semibold opacity-80">Years of Excellence</p>
                </div>
              </motion.div>

              {/* Decorative Element */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-emerald-100 rounded-full opacity-50 blur-2xl" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-20 md:py-28 bg-white relative">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-100 border border-amber-200 mb-6">
              <Target className="w-4 h-4 text-amber-600" />
              <span className="text-sm font-medium text-amber-700">Our Purpose</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900">
              Guided by{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-yellow-500">
                Purpose & Vision
              </span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6 lg:gap-8 max-w-6xl mx-auto">
            {/* Mission Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl transform rotate-1 group-hover:rotate-2 transition-transform duration-500" />
              <div className="relative bg-gradient-to-br from-emerald-800 to-teal-900 p-8 md:p-10 lg:p-12 rounded-3xl overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
                
                <div className="relative z-10">
                  <div className="inline-flex p-3 rounded-2xl bg-white/10 backdrop-blur-sm mb-6">
                    <Target className="w-8 h-8 text-emerald-300" />
                  </div>
                  <h3 className="font-serif text-2xl md:text-3xl font-bold text-white mb-4">
                    Our Mission
                  </h3>
                  <p className="text-emerald-100/90 leading-relaxed text-lg">
                    To provide accessible, authentic, and comprehensive Quranic education 
                    that nurtures both the intellectual understanding and spiritual connection 
                    with the Holy Quran, guided by qualified scholars in a supportive 
                    learning environment.
                  </p>
                  
                  <div className="mt-8 pt-6 border-t border-white/10">
                    <div className="flex items-center gap-3">
                      <Quote className="w-5 h-5 text-emerald-300" />
                      <p className="text-emerald-200/80 italic text-sm">
                        "The best among you are those who learn the Quran and teach it."
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Vision Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-yellow-600 rounded-3xl transform -rotate-1 group-hover:-rotate-2 transition-transform duration-500" />
              <div className="relative bg-gradient-to-br from-amber-400 to-yellow-500 p-8 md:p-10 lg:p-12 rounded-3xl overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />
                
                <div className="relative z-10">
                  <div className="inline-flex p-3 rounded-2xl bg-white/20 backdrop-blur-sm mb-6">
                    <Sparkles className="w-8 h-8 text-amber-900" />
                  </div>
                  <h3 className="font-serif text-2xl md:text-3xl font-bold text-amber-900 mb-4">
                    Our Vision
                  </h3>
                  <p className="text-amber-900/80 leading-relaxed text-lg">
                    To become the world's leading online Quran academy, producing generations 
                    of Muslims who not only recite the Quran beautifully but also understand, 
                    practice, and spread its timeless teachings in their daily lives.
                  </p>
                  
                  <div className="mt-8 pt-6 border-t border-amber-900/10">
                    <div className="flex items-center gap-3">
                      <Star className="w-5 h-5 text-amber-800" />
                      <p className="text-amber-800/80 italic text-sm">
                        Building bridges between hearts and the Divine Word.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 md:py-28 bg-gradient-to-b from-slate-50 to-white relative overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-100 border border-purple-200 mb-6">
              <BookOpen className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-700">Our Journey</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Milestones of{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-violet-600">
                Our Growth
              </span>
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              From humble beginnings to a global community, see how we've grown over the years.
            </p>
          </motion.div>

          {/* Timeline */}
          <div className="max-w-4xl mx-auto relative">
            {/* Timeline Line */}
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500 transform md:-translate-x-1/2" />

            {milestones.map((milestone, index) => (
              <motion.div
                key={milestone.year}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative flex items-start gap-6 md:gap-12 mb-12 last:mb-0 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Dot */}
                <div className="absolute left-4 md:left-1/2 w-4 h-4 rounded-full bg-white border-4 border-emerald-500 transform -translate-x-1/2 mt-1.5 shadow-lg shadow-emerald-200" />

                {/* Content */}
                <div className={`flex-1 ml-12 md:ml-0 ${index % 2 === 0 ? 'md:text-right md:pr-16' : 'md:text-left md:pl-16'}`}>
                  <div className={`inline-block ${index % 2 === 0 ? 'md:ml-auto' : ''}`}>
                    <span className="inline-block px-3 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-sm font-bold mb-3">
                      {milestone.year}
                    </span>
                    <h3 className="font-serif text-xl md:text-2xl font-bold text-slate-900 mb-2">
                      {milestone.title}
                    </h3>
                    <p className="text-slate-600 leading-relaxed">
                      {milestone.description}
                    </p>
                  </div>
                </div>

                {/* Spacer for opposite side */}
                <div className="hidden md:block flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 md:py-28 bg-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-[url('/pattern-dots.svg')] opacity-5" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-rose-100 border border-rose-200 mb-6">
              <Heart className="w-4 h-4 text-rose-600" />
              <span className="text-sm font-medium text-rose-700">Our Values</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              The Principles That{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-pink-500">
                Guide Us
              </span>
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              Every decision we make is rooted in these core values that define who we are.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8"
          >
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                variants={itemVariants}
                className="group"
              >
                <div className="h-full bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-lg shadow-slate-100/50 hover:shadow-xl hover:shadow-slate-200/50 hover:border-slate-200 hover:-translate-y-1 transition-all duration-500">
                  <div className={`w-14 h-14 rounded-2xl ${value.bgColor} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300`}>
                    <value.icon className={`w-7 h-7 ${value.iconColor}`} />
                  </div>
                  <h3 className="font-serif text-xl md:text-2xl font-bold text-slate-900 mb-3">
                    {value.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {value.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 md:py-28 bg-gradient-to-b from-slate-50 to-white relative overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-100 border border-indigo-200 mb-6">
              <Users className="w-4 h-4 text-indigo-600" />
              <span className="text-sm font-medium text-indigo-700">Our Team</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Meet Our{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-500">
                Distinguished Scholars
              </span>
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              Our team of dedicated scholars and educators are committed to 
              providing the highest quality Quranic education with love and expertise.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 lg:gap-10 max-w-6xl mx-auto"
          >
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                variants={itemVariants}
                className="group text-center"
              >
                <div className="relative mb-6 inline-block">
                  {/* Decorative Ring */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 transform rotate-6 group-hover:rotate-12 transition-transform duration-500" style={{ padding: '4px' }}>
                    <div className="w-full h-full rounded-full bg-slate-50" />
                  </div>
                  
                  {/* Image Container */}
                  <div className="relative w-36 h-36 md:w-44 md:h-44 rounded-full overflow-hidden border-4 border-white shadow-xl group-hover:scale-105 transition-transform duration-500">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* Status Badge */}
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-emerald-500 text-white text-xs font-semibold rounded-full shadow-lg">
                    Available
                  </div>
                </div>

                <h3 className="font-serif text-xl md:text-2xl font-bold text-slate-900 mb-1">
                  {member.name}
                </h3>
                <p className="text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-yellow-500 font-semibold mb-3">
                  {member.role}
                </p>
                <p className="text-slate-600 text-sm leading-relaxed mb-4 max-w-xs mx-auto">
                  {member.description}
                </p>

                {/* Credentials */}
                <div className="flex flex-wrap justify-center gap-2">
                  {member.credentials.map((credential) => (
                    <span 
                      key={credential}
                      className="px-3 py-1 text-xs font-medium bg-slate-100 text-slate-600 rounded-full"
                    >
                      {credential}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* View All Team Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <Button 
              variant="outline" 
              size="lg"
              className="h-12 px-8 rounded-xl border-2 border-slate-200 hover:border-emerald-300 hover:bg-emerald-50 transition-all duration-300 group"
            >
              View All Instructors
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 md:py-28 bg-gradient-to-br from-emerald-900 via-teal-800 to-cyan-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/pattern-islamic.svg')] opacity-5" />
        <motion.div 
          animate={floatingAnimation}
          className="absolute top-20 right-20 w-40 h-40 bg-gold/10 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ ...floatingAnimation, transition: { ...floatingAnimation.transition, delay: 1.5 } }}
          className="absolute bottom-20 left-20 w-60 h-60 bg-emerald-400/10 rounded-full blur-3xl"
        />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex p-4 rounded-full bg-white/10 backdrop-blur-sm mb-8">
              <Quote className="w-8 h-8 text-gold" />
            </div>
            
            <blockquote className="font-serif text-2xl sm:text-3xl md:text-4xl text-white leading-relaxed mb-8">
              "Miftah Al Quran transformed my relationship with the Holy Quran. 
              The teachers are incredibly patient and knowledgeable. I went from 
              struggling with basic recitation to now memorizing with proper Tajweed."
            </blockquote>

            <div className="flex items-center justify-center gap-4">
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-gold">
                <img 
                  src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100" 
                  alt="Student"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-left">
                <p className="text-white font-semibold">Sarah Johnson</p>
                <p className="text-white/60 text-sm">Student since 2021 • USA</p>
              </div>
            </div>

            {/* Rating */}
            <div className="flex justify-center gap-1 mt-6">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 text-gold fill-gold" />
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <CallToAction />
      <Footer />
    </div>
  );
}